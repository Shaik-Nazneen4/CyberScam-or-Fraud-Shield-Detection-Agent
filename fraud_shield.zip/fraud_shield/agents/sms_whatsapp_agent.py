"""SMS & WhatsApp Scam Detection Sub-Agent.

Analyzes text/messages for smishing, WhatsApp hijacking patterns, support impersonations,
and verification code (OTP) harvesting.
"""

import logging
from fraud_shield.agents.base import BaseSubAgent
from fraud_shield.interfaces import AgentResult
from fraud_shield.registry import AgentRegistry

logger = logging.getLogger(__name__)

@AgentRegistry.register(
    name="SMS & WhatsApp Scam Detection Agent",
    description="Analyzes SMS and WhatsApp messages for smishing, verification requests, and account hijacking flags."
)
class SmsWhatsAppScamDetectionAgent(BaseSubAgent):
    """Sub-agent specialized in identifying mobile messaging scams."""

    @property
    def name(self) -> str:
        return "SMS & WhatsApp Scam Detection Agent"

    @property
    def description(self) -> str:
        return "Analyzes SMS and WhatsApp messages for smishing, verification requests, and account hijacking flags."

    def analyze(self, content: str) -> AgentResult:
        logger.info(f"Running SMS/WhatsApp analysis on: {content[:40]}...")
        content_lower = content.lower()
        findings = []
        risk_level = "LOW"
        confidence = 0.90
        
        # Look for smishing/hijacking indicators
        if "otp" in content_lower or "one time password" in content_lower or "verification code" in content_lower:
            findings.append("Critical threat: Request for One-Time Password (OTP) or Verification Code detected.")
            risk_level = "CRITICAL"
        if "bank called" in content_lower or "security alert" in content_lower or "unusual login" in content_lower:
            findings.append("Bank impersonation / social engineering tactics identified.")
            risk_level = "HIGH" if risk_level == "LOW" else risk_level
        if "click here to verify" in content_lower or "wa.me" in content_lower:
            findings.append("Suspicious messaging redirect link detected.")
            risk_level = "MEDIUM" if risk_level == "LOW" else risk_level
        if "family in need" in content_lower or "accident" in content_lower or "mom" in content_lower:
            findings.append("Potential emergency/family-impersonation scam pattern.")
            risk_level = "HIGH"

        if not findings:
            findings.append("No common SMS or WhatsApp threat indicators identified.")
            confidence = 0.65

        return AgentResult(
            agent_name=self.name,
            risk_level=risk_level,
            confidence=confidence,
            findings=findings,
            details={"contains_otp_request": "otp" in content_lower}
        )

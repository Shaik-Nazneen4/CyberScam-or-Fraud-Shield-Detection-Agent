"""Internship & Job Scam Detection Sub-Agent.

Analyzes job listings, internship offers, hiring messages, and onboarding procedures
for advance-fee job scams, fake corporate domains, and task-based financial scams.
"""

import logging
from fraud_shield.agents.base import BaseSubAgent
from fraud_shield.interfaces import AgentResult
from fraud_shield.registry import AgentRegistry

logger = logging.getLogger(__name__)

@AgentRegistry.register(
    name="Internship & Job Scam Detection Agent",
    description="Evaluates job listings and internship offers for advance-fee scams, suspicious recruiting, and tasks scams."
)
class JobScamDetectionAgent(BaseSubAgent):
    """Sub-agent specialized in identifying job and internship scams."""

    @property
    def name(self) -> str:
        return "Internship & Job Scam Detection Agent"

    @property
    def description(self) -> str:
        return "Evaluates job listings and internship offers for advance-fee scams, suspicious recruiting, and tasks scams."

    def analyze(self, content: str) -> AgentResult:
        logger.info(f"Running job/internship analysis on: {content[:40]}...")
        content_lower = content.lower()
        findings = []
        risk_level = "LOW"
        confidence = 0.86
        
        # Check job scam indicators
        if "telegram" in content_lower or "whatsapp" in content_lower:
            if "interview" in content_lower or "recruit" in content_lower:
                findings.append("Recruitment process conducted entirely on personal chat apps (Telegram/WhatsApp), which is highly unprofessional and indicates a scam.")
                risk_level = "HIGH"
                
        if "pay" in content_lower or "salary" in content_lower or "earn" in content_lower:
            if "quick" in content_lower or "easy" in content_lower or "no experience" in content_lower:
                findings.append("High compensation promised for low-skill, low-effort work (e.g. 'earn $500/day clicking links').")
                risk_level = "HIGH"
                
        if "deposit" in content_lower or "pay for training" in content_lower or "buy equipment" in content_lower:
            findings.append("Advance-fee job scam: demands payment for training materials, background checks, or startup equipment.")
            risk_level = "CRITICAL"

        if not findings:
            findings.append("No obvious internship or job scam patterns detected.")
            confidence = 0.70

        return AgentResult(
            agent_name=self.name,
            risk_level=risk_level,
            confidence=confidence,
            findings=findings,
            details={"is_job_intent": True}
        )

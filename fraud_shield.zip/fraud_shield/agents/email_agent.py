"""Email Scam Detection Sub-Agent.

Analyzes text for indicators of email phishing, wire transfer fraud, lottery scams,
and impersonation attempts.
"""

import logging
from fraud_shield.agents.base import BaseSubAgent
from fraud_shield.interfaces import AgentResult
from fraud_shield.registry import AgentRegistry

logger = logging.getLogger(__name__)

@AgentRegistry.register(
    name="Email Scam Detection Agent",
    description="Analyzes email content for phishing, impersonation, urgency, and financial scams."
)
class EmailScamDetectionAgent(BaseSubAgent):
    """Sub-agent specialized in identifying email-based fraud."""

    @property
    def name(self) -> str:
        return "Email Scam Detection Agent"

    @property
    def description(self) -> str:
        return "Analyzes email content for phishing, impersonation, urgency, and financial scams."

    def analyze(self, content: str) -> AgentResult:
        logger.info(f"Running email analysis on: {content[:40]}...")
        content_lower = content.lower()
        findings = []
        risk_level = "LOW"
        confidence = 0.85
        
        # Look for phishing / scam markers
        if "inheritance" in content_lower or "prince" in content_lower or "lottery" in content_lower:
            findings.append("Detected classic advance-fee fraud keywords (lottery/inheritance).")
            risk_level = "HIGH"
        if "urgent" in content_lower or "immediate action" in content_lower or "suspend" in content_lower:
            findings.append("Urgency-inducing language identified (often used to force rash decisions).")
            risk_level = "MEDIUM" if risk_level == "LOW" else risk_level
        if "bank" in content_lower or "verify your password" in content_lower or "login" in content_lower:
            findings.append("Credential phishing risk: requests credentials or links to login portals.")
            risk_level = "HIGH"
        if "gift card" in content_lower or "wire transfer" in content_lower:
            findings.append("Request for non-reversible payment methods detected (gift cards, wire transfers).")
            risk_level = "CRITICAL" if "urgent" in content_lower else "HIGH"

        if not findings:
            findings.append("No obvious email scam markers detected.")
            confidence = 0.70

        return AgentResult(
            agent_name=self.name,
            risk_level=risk_level,
            confidence=confidence,
            findings=findings,
            details={"analyzed_length": len(content)}
        )

"""LLM Provider module.

Exposes the abstract base ModelProvider class and its implementations.
"""

from fraud_shield.llm.base import ModelProvider
from fraud_shield.llm.mock_provider import MockModelProvider

__all__ = ["ModelProvider", "MockModelProvider"]
